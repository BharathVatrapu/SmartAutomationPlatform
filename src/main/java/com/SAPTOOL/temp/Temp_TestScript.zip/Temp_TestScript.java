package com.testProject.testSuites;

import com.testProject.testBase.TestBase;
import org.testng.annotations.Test;

public class Temp_TestScript extends TestBase {

    @Test(groups={"SignIn"})
    public void Temp_TestScript() throws Exception {
        //SAP-START - VARIABLE DECLARAITON
        //SAP-END - VARIABLE DECLARAITON

        //SAP-START - TEST SCRIPT
        //SAP-END - TEST SCRIPT
    }
}
