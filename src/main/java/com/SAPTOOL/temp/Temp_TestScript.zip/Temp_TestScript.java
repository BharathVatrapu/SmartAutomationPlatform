package com.testProject.testSuites;

import com.testProject.testBase.TestBase;
import com.testProject.testConstants.GlobalConstants;
import org.testng.annotations.Test;

import java.io.File;

public class Temp_TestScript extends TestBase {

    @Test(groups={""})
    public void Temp_TestScript() throws Exception {
        //SAP-START - VARIABLE DECLARAITON
            configTestData.jsonObject = driverGeneric.parseStringToJsonObject(GlobalConstants.TEST_DATA_FILE_PATH+ configTestData.testModule+File.separator+configTestData.testMethod_Name.toUpperCase()+".json");
        //SAP-END - VARIABLE DECLARAITON

        //SAP-START - TEST SCRIPT

        //SAP-END - TEST SCRIPT
    }

}
