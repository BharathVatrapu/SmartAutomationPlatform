package com.testProject.testConstants;

public class GlobalConstants {
}
