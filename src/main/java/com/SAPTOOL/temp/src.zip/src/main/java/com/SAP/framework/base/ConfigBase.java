package com.SAP.framework.base;

import com.SAP.framework.utils.*;
import com.aventstack.extentreports.Status;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

public class ConfigBase {

    public ConfigTestData configTestData=new ConfigTestData();
    public ExtentManager extentManager = new ExtentManager(configTestData);

    public ConfigDriver configDriver = null;
    public Screenshot screenshotGenarator = null;
    public Generic generic = null;
    public DriverGeneric driverGeneric = null;

    HashMap<String, String> enviornmentHashmap = null;

    //SAP-START   -   BeforeSuite
    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(){
        try {


        } catch (Exception e){
            e.printStackTrace();
        }
    }
    //SAP-END   -   BeforeSuite
    //SAP-START   -   BeforeTest
    @BeforeTest(alwaysRun = true)
    public void extentReportConfig(ITestContext context) {
        String reportName = null;
        String groupName = null;
        configTestData.suiteXml_Name = context.getSuite().getName();
        // groupName=generic.getSuiteXmlGroupName(context.getIncludedGroups());
        reportName = configTestData.suiteXml_Name + "_[" + DateAndTime.getTime() +"]_"+ DateAndTime.getDate()+".html";
        extentManager.createReportFile(reportName);
    }
    //SAP-END   -   BeforeTest

    //SAP-START   -   BeforeMethod
    @Parameters({"browser","environment","platform","module","banner"})
    @BeforeMethod(alwaysRun = true)
    public void initSetup(Method testMethod, @Optional("optional") String browser, @Optional("optional") String environment, @Optional("optional") String platform, @Optional("optional") String module, @Optional("optional") String banner) {
        initClass();
        if(System.getProperty("browser")!=null) {
            configTestData.testBrowser = System.getProperty("browser").toLowerCase();
            configTestData.testEnvironment = System.getProperty("environment").toLowerCase();
            configTestData.testPlatform = System.getProperty("platform").toLowerCase();
            configTestData.testModule = System.getProperty("module").toLowerCase();
            configTestData.testBanner = System.getProperty("banner").toLowerCase();
        }else {
            configTestData.testBrowser = browser.toLowerCase();
            configTestData.testEnvironment = environment.toLowerCase();
            configTestData.testPlatform = platform.toLowerCase();
            configTestData.testModule = module.toLowerCase();
            configTestData.testBanner = banner.toLowerCase();
        }

        try {
            configTestData.testMethod_Name = testMethod.getName();
            initDriver();
            extentManager.createTest(configTestData.testMethod_Name);
        } catch (Exception e){
            e.printStackTrace();
        }
        Test testClass = testMethod.getAnnotation(Test.class);
        configTestData.suiteXmlgroup_Name = testClass.groups()[0];
      //  loadTestData(testClass.groups()[0],banner,environment);
        Log.info(configTestData.testMethod_Name + " :: TestScript is Start");

    }
    //SAP-END   -   BeforeMethod

    //SAP-START   -   AfterMethod
    @AfterMethod(alwaysRun = true)
    protected void afterMethod(ITestResult result) {
        for(String group:result.getMethod().getGroups()){
            extentManager.assignGroup(group);
        }
        try{
            configTestData.driver.quit();
            extentManager.addfinalStatus(configTestData.finalTestCaseStatus);
        } catch (Exception e){
            e.printStackTrace();
        }

        Log.info(configTestData.testMethod_Name + " :: TestScript is End");
        Log.info("===================================================================");
    }
    //SAP-END   -   AfterMethod

    //SAP-START   -   AfterTest
    @AfterTest(alwaysRun = true)
    public void tearDown() {
        try{
            enviornmentHashmap = new HashMap<String, String>();
            enviornmentHashmap.put("OS",Generic.getCurretnPlatform().toString());
            enviornmentHashmap.put("UserName",System.getProperty("user.name"));
            enviornmentHashmap.put("Environment",configTestData.testEnvironment.toUpperCase());
            enviornmentHashmap.put("Browser",configTestData.testBrowser.toUpperCase());
            extentManager.setSystemInfo(enviornmentHashmap);


            extentManager.assignLog(generic.readFile(ConfigTestData.WORKING_DIR+ "/src/main/resources/log/Testomation.log"));
            extentManager.setHtmlConfig(configTestData.suiteXml_Name);
            extentManager.flush();

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    //SAP-END   -   AfterTest

    public void initClass(){
        configDriver = new ConfigDriver(configTestData);
        screenshotGenarator = new Screenshot(configTestData);
        generic = new Generic(configTestData);
        driverGeneric=new DriverGeneric(configTestData);
    }

    public void initDriver(){
        try {
//            configDriver = new ConfigDriver(configTestData);
            configDriver.initDriver();
            System.out.println("base:"+configTestData.driver);
            //  Set Objet Defination file path
            //  generic.getObjectDefFile();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void verify(boolean condition, String message){
        configTestData.stepNo = configTestData.stepNo+1;
        if(condition){
            extentManager.addExecutionStep(Status.PASS,message);
        } else{
            if(message.contains(" is not ")){
                message = message.replaceAll(" is not ", " is ");
            } else {
                message = message.replaceAll(" is ", " is not ");
            }
            extentManager.addExecutionStep(Status.FAIL,message);
            configTestData.finalTestCaseStatus = Status.FAIL;
        }
    }
    public void verify(String condition, String trueMsg,String falseMsg){
        configTestData.stepNo = configTestData.stepNo+1;
        if(condition.toLowerCase() == "true"){
            extentManager.addExecutionStep(Status.PASS,trueMsg);
        } else{
            extentManager.addExecutionStep(Status.FAIL,falseMsg);
            configTestData.finalTestCaseStatus = Status.FAIL;
        }
    }
    public String verify(boolean condition){
        configTestData.stepNo = configTestData.stepNo+1;
        if(condition){
            return "true";
        } else{
            return "false";
        }
    }

    public void Assert(boolean condition,String trueMsg,String falseMsg){
        configTestData.stepNo = configTestData.stepNo+1;

        if(condition){
            extentManager.addExecutionStep(Status.PASS,trueMsg);
        } else{
            extentManager.addExecutionStep(Status.FAIL,falseMsg);
            configTestData.finalTestCaseStatus = Status.FAIL;
        }
        Assert.assertTrue(condition,falseMsg);
    }

    public String td(String keyStr) {
        String valStr=null;

        try {
            JSONParser parser = new JSONParser();
            //Object obj = parser.parse(new FileReader(jsonPath));

            // JSONObject jsonObject = (JSONObject) obj;
            valStr=configTestData.jsonObject.get(keyStr).toString();

        }catch (Exception e){
            e.printStackTrace();
        }

        return valStr;
    }
}
