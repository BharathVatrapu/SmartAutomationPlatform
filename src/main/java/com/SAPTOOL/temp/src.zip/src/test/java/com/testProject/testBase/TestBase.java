package com.testProject.testBase;

//SAP-START   - IMPORT DECLARATION
import com.SAP.framework.base.ConfigBase;
import com.SAP.framework.utils.DriverGeneric;
import org.testng.annotations.BeforeMethod;
//SAP-END   - IMPORT DECLARATION

public class TestBase extends ConfigBase {

    //SAP-START   - PAGE DECLARATION   
    //SAP-END   - PAGE DECLARATION

    @BeforeMethod(alwaysRun = true)
    public void initTestMethods(){
        initilizePages();
    }

    public void initilizePages(){
        //SAP-START   - PAGE INITILAZATION       
        //SAP-END   - PAGE INITILAZATION
    }
}
