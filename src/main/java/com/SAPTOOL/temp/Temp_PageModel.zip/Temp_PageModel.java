package com.testProject.testPages;

import com.SAP.framework.base.ConfigTestData;
import com.SAP.framework.utils.DriverGeneric;
import com.SAP.framework.utils.Log;
import com.testProject.testBase.TestBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Temp_PageModel extends TestBase {

//SAP-START - CONSTRUCTOR DECLARAITON
    public Temp_PageModel(ConfigTestData configTestData) {
        PageFactory.initElements(configTestData.driver,this);
    }
//SAP-END - CONSTRUCTOR DECLARAITON

//SAP-START - VARIABLE DECLARAITON
//SAP-END - VARIABLE DECLARAITON
			
//SAP-START - OBJECT DECLARAITON
//SAP-END - OBJECT DECLARAITON
		
//SAP-START - OPERATION DECLARAITON
//SAP-END - OPERATION DECLARAITON
		
//SAP-START - METHOD DECLARAITON
//SAP-END - METHOD DECLARAITON
}
