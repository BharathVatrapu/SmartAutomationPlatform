package com.testProject.testsuites.signin;

import com.testProject.base.TestBase;
import org.testng.annotations.Test;

public class VerifySignIn extends TestBase {

    @Test(groups={"SignIn"})
    public void VerifySignIn() throws Exception {
       //Variable Declarion

        //Step 1:
        verify(signinPage.gotoSignInPage(),"SignIn page is displayed");
       
    }

}
