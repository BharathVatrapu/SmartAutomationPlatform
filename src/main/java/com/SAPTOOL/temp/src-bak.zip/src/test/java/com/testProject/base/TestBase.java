package com.testProject.base;

//IMPORT DECLARATION - START
import com.testomation.framework.base.ConfigBase;
import org.testng.annotations.BeforeMethod;
//IMPORT DECLARATION - END

public class TestBase extends ConfigBase {

    //PAGE DECLARATION - START    
	//PAGE DECLARATION - END

    @BeforeMethod(alwaysRun = true)
    public void initTestMethods(){
        initilizePages();
    }

    public void initilizePages(){
        //PAGE INITILAZATION - START        
		//PAGE INITILAZATION - END
    }
}
