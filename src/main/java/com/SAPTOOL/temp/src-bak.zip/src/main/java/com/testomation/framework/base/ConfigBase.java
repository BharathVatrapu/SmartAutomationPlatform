package com.testomation.framework.base;

import com.aventstack.extentreports.Status;
import com.testomation.framework.utils.*;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.*;
import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;

public class ConfigBase {

    public ConfigTestData configTestData=new ConfigTestData();
    public ConfigDriver configDriver = null;
    public ScreenshotGenarator screenshotGenarator = null;
    public ExtentManager extentManager = new ExtentManager(configTestData);
    public Generic generic=null;

    static ResourceBundle rbTestdata =null;
    HashMap<String, String> enviornmentHashmap = null;


    @BeforeSuite(alwaysRun = true)
    public void beforeSuite(){
        try {


        } catch (Exception e){
            e.printStackTrace();
        }
    }

    @BeforeTest(alwaysRun = true)
    public void extentConfig(ITestContext context) {
        String reportName = null;
        String groupName = null;
        configTestData.suiteXmlName = context.getSuite().getName();
       // groupName=generic.getSuiteXmlGroupName(context.getIncludedGroups());
        reportName = configTestData.suiteXmlName + "_[" + DateAndTime.getTime() +"]_"+DateAndTime.getDate()+".html";
        extentManager.createReportFile(reportName);
    }


    @Parameters({"browser","environment","platform","module","param1"})
    @BeforeMethod(alwaysRun = true)
    public void initSetup(Method testMethod,@Optional("optional") String browser,@Optional("optional") String environment,@Optional("optional") String platform,@Optional("optional") String module,@Optional("optional") String param1) throws Exception {
        initClass();
        if(System.getProperty("browser")!=null) {
            configTestData.testBrowser = System.getProperty("browser").toLowerCase();
            configTestData.testEnvironment = System.getProperty("environment").toLowerCase();
            configTestData.testPlatform = System.getProperty("platform").toLowerCase();
            configTestData.testModule = System.getProperty("module").toLowerCase();
            configTestData.testParam1 = System.getProperty("param1").toLowerCase();
        }else {
            configTestData.testBrowser = browser.toLowerCase();
            configTestData.testEnvironment = environment.toLowerCase();
            configTestData.testPlatform = platform.toLowerCase();
            configTestData.testModule = module.toLowerCase();
            configTestData.testParam1 = param1.toLowerCase();
        }

        try {
            configTestData.testMethodName = testMethod.getName();
            initDriver();

            extentManager.createTest(configTestData.testMethodName);
        } catch (Exception e){
            e.printStackTrace();
        }
        Test testClass = testMethod.getAnnotation(Test.class);
        configTestData.groupName = testClass.groups()[0];
        loadTestData(testClass.groups()[0],param1,environment);
        Log.info(configTestData.testMethodName + " :: TestScript is Start");

    }

    @AfterMethod(alwaysRun = true)
    protected void afterMethod(ITestResult result) {

        for(String group:result.getMethod().getGroups()){
            extentManager.assignGroup(group);
        }
        try{
            configTestData.driver.quit();
            extentManager.addfinalStatus(configTestData.finalTestCaseStatus);
        } catch (Exception e){
            e.printStackTrace();
        }

        Log.info(configTestData.testMethodName + " :: TestScript is End");
        Log.info("===================================================================");

    }

    public void initClass(){
        configDriver = new ConfigDriver(configTestData);
        screenshotGenarator = new ScreenshotGenarator(configTestData);
        generic = new Generic(configTestData);
    }

    public void initDriver(){
        try {
//            configDriver = new ConfigDriver(configTestData);
            configDriver.initDriver();
            //  Set Objet Defination file path
          //  generic.getObjectDefFile();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @AfterTest(alwaysRun = true)
    public void tearDown() {

        try{
            enviornmentHashmap = new HashMap<String, String>();
            enviornmentHashmap.put("OS",Generic.getCurretnPlatform().toString());
            enviornmentHashmap.put("UserName",System.getProperty("user.name"));
            enviornmentHashmap.put("Environment",configTestData.testEnvironment.toUpperCase());
            enviornmentHashmap.put("Browser",configTestData.testBrowser.toUpperCase());
            extentManager.setSystemInfo(enviornmentHashmap);


            extentManager.assignLog(generic.readFile(ConfigTestData.workDir+ "/src/main/resources/log/Testomation.log"));
            extentManager.setHtmlConfig(configTestData.suiteXmlName);
            extentManager.flush();

        } catch (Exception e){
            e.printStackTrace();
        }
    }
    public static ResourceBundle loadTestData(String module,String banner,String env) throws Exception{

        File file = new File(Generic.getTestDataPath());
        URL[] urls = {file.toURI().toURL()};
        ClassLoader loader = new URLClassLoader(urls);
        return rbTestdata = ResourceBundle.getBundle(env+"_"+banner+"_"+module, Locale.getDefault(), loader);
    }

    public void verify(boolean condition, String message){
        configTestData.stepNo = configTestData.stepNo+1;
        if(condition){
            extentManager.addExecutionStep(Status.PASS,message);
        } else{
            if(message.contains(" is not ")){
                message = message.replaceAll(" is not ", " is ");
            } else {
                message = message.replaceAll(" is ", " is not ");
            }
            extentManager.addExecutionStep(Status.FAIL,message);
            configTestData.finalTestCaseStatus = Status.FAIL;
        }
    }
    public void verify(boolean condition, String trueMsg,String falseMsg){
        configTestData.stepNo = configTestData.stepNo+1;
        if(condition){
            extentManager.addExecutionStep(Status.PASS,trueMsg);
        } else{
            extentManager.addExecutionStep(Status.FAIL,falseMsg);
            configTestData.finalTestCaseStatus = Status.FAIL;
        }
    }

    public void Assert(boolean condition,String trueMsg,String falseMsg){
        configTestData.stepNo = configTestData.stepNo+1;

        if(condition){
            extentManager.addExecutionStep(Status.PASS,trueMsg);
        } else{
            extentManager.addExecutionStep(Status.FAIL,falseMsg);
            configTestData.finalTestCaseStatus = Status.FAIL;
        }
        Assert.assertTrue(condition,falseMsg);
    }
}
